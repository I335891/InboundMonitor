sap.ui.controller("com.sapzjitimqj9.ext.controller.ListReportExt", {

	onClickActionZ_C_JITIMONITORSource1: function(oEvent) {
		//sap.m.MessageToast.show("Hello World!");
		var that = this;
		if (oEvent.getSource().getParent().getParent().getItems()[1].getSelectedItems().length !== 0) {
			if (!this._DialogGenerate || this._DialogGenerate === "") {
				var table = oEvent.getSource().getParent().getParent().getItems()[1];
				var selectedItem = table.getSelectedItems()[0];
				var bindingContextPath = selectedItem.getBindingContext().getPath();
				var binding = this.getView().getModel().getProperty(bindingContextPath);
				var Cnrtl = binding.CallControl;
				var Intst = binding.InternalProcessingStatus;
				var Dcrea = binding.DeliveryCreated;
				var Created;
				if(Dcrea == true){
					Created = 'X';
				}
				else{
					Created = '';
				}
				
				 
				var oModel1 = new sap.ui.model.json.JSONModel();
				oModel1 = binding;
				this.getView().setModel(oModel1, "ChosenOne");

				/*	var Custo = binding.JITCustomer;
					var Jinum = binding.CallNumber;
					var Posid = binding.ComponentGroupNumber;
					var Anlie = binding.ComponentGroupType;
					var Desti = binding.Destination;
					var Matid = binding.ComponentNumber;
				*/

				var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZJITIMONITOR_SRV/");
				oDataModel.callFunction("status", // function import name
					"GET", // http method
					{
						"Cnrtl": Cnrtl,
						"Intst": Intst,
						"Dcrea": Created
					}, // function import parameters
					null,
					function(oData, response) {
						var oModel = new sap.ui.model.json.JSONModel({
							res: oData.results
						});

						//oModel.setData(oData.results);
						that.getView().setModel(oModel, "Action");
						that._DialogGenerate = sap.ui.xmlfragment("com.sapzjitimqj9.ext.fragment.GenerateSrclistSmart", that).addStyleClass(
							"sapUiSizeCompact");
						that.getView().addDependent(that._DialogGenerate);
						that._DialogGenerate.open();
					}, // callback function for success
					function(oError) {

					},
					false); // callback function for error

			}
		} else {
			sap.m.MessageToast.show("Action can be performed only if the item is selected");
		}

	},

	onAppendGeneratedSrcList: function(oEvent) {
		//sap.m.MessageToast.show("Hello World!");
		var that = this;

		var table = oEvent.getSource().getParent().getContent()[0].getItems()[0].getItems()[1];
		var selectedItem = table.getSelectedItems()[0];
		var bindingContextPath = selectedItem.getBindingContext("Action").getPath();
		var binding = this.getView().getModel("Action").getProperty(bindingContextPath);
		var Aktion = binding.Aktion;
		var oModel = this.getView().getModel("ChosenOne");
		var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZJITIMONITOR_SRV/");
		oDataModel.callFunction("action", // function import name
			"GET", // http method
			{
				"Aktion": Aktion,
				"CallComponent": oModel.ComponentNumber,
				"CallNumber": oModel.CallNumber,
				"CGNumber": oModel.ComponentGroupNumber,
				"CGType": oModel.ComponentGroupType,
				"Destination": oModel.Destination,
				"JitCustomer": oModel.JITCustomer
			}, // function import parameters
			null,
			function(oData, response) {
				var oModel1 = new sap.ui.model.json.JSONModel({
					res: oData.results
				});

				//oModel.setData(oData.results);
				that.getView().setModel(oModel1, "Action");
				that._DialogGenerate.destroy();
				that._DialogGenerate = "";
				sap.m.MessageToast.show("Delivery Created");
				that._DialogGenerate = sap.ui.xmlfragment("com.sapzjitimqj9.ext.fragment.GenerateSrclistSmart", that).addStyleClass(
					"sapUiSizeCompact");
				that.getView().addDependent(that._DialogGenerate);
				that._DialogGenerate.open();
			}, // callback function for success
			function(oError) {

			},
			false); // callback function for error

	},
	onDialogGenerateClose: function() {
		this._DialogGenerate.destroy();
		this._DialogGenerate = "";
		//	this._DialogGenerate.destroyContent();
		this.getView().getModel().refresh();
	}
});